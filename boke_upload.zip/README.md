<<<<<<< HEAD
# Hugo-
=======
# Hugo 博客项目

本项目为 Hugo 静态博客，适用于 Vercel 自动化部署。

## 快速开始

1. 安装 Hugo（本地开发可选）：
   - 参考 <https://gohugo.io/getting-started/installing/>

2. 克隆本仓库并进入目录：

   ```sh
   git clone <your-repo-url>
   cd <your-repo-name>
   ```

3. 本地预览（可选）：

   ```sh
   hugo server -D
   ```

4. 推送到 GitHub 后，Vercel 会自动检测并部署。

## Vercel 配置

- 构建命令：`hugo --minify`
- 输出目录：`public`
- 推荐在项目根目录添加 `vercel.json` 文件：

```
{
  "builds": [
    { "src": "package.json", "use": "@vercel/static-build", "config": { "distDir": "public" } }
  ],
  "routes": [
    { "src": "/(.*)", "dest": "/$1" }
  ]
}
```

## 参考文档

- Hugo 官方文档：<https://gohugo.io/>
- Vercel 官方文档：<https://vercel.com/docs>
>>>>>>> 6b565d2 (init: hugo blog with auto ai hot post)
