# 自动AI热点内容生成与推送脚本
# 依赖：openai, requests, schedule, gitpython
# 使用前请在本目录下创建 .env 文件，写入 OPENAI_API_KEY=你的key

import os
import requests
import openai
import schedule
import time
import datetime
import random
from git import Repo
from dotenv import load_dotenv

# 加载 OpenAI API Key
load_dotenv()
openai.api_key = os.getenv('OPENAI_API_KEY')

# 热点抓取函数（示例：百度热搜）
def fetch_baidu_hot():
    url = 'https://top.baidu.com/board?tab=realtime'
    resp = requests.get(url)
    # 这里只做演示，实际可用 BeautifulSoup 或正则提取标题
    # TODO: 可扩展抓取今日头条、知乎、谷歌趋势等
    return ['示例热点1', '示例热点2', '示例热点3']

# 多个 OpenAI Key 轮询
OPENAI_KEYS = [
    os.getenv('OPENAI_API_KEY'),
    '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',
    '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',
    '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',
]

def get_random_key():
    return random.choice([k for k in OPENAI_KEYS if k])

# AI 生成文章
def generate_article(title):
    openai.api_key = get_random_key()
    prompt = f"请以'{title}'为主题，写一篇约500字的中文热点资讯文章，风格简洁有深度。"
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": prompt}]
    )
    return response.choices[0].message.content.strip()

# 写入 Markdown 文件
def write_post(title, content):
    now = datetime.datetime.now()
    safe_title = title.replace(' ', '-').replace('/', '-')
    filename = f"content/posts/{now.strftime('%Y%m%d%H%M%S')}-{safe_title}.md"
    with open(filename, 'w', encoding='utf-8') as f:
        f.write(f"+++\ntitle = '{title}'\ndate = '{now.isoformat()}'\ndraft = false\n+++\n\n{content}\n")
    return filename

# Git 自动提交推送
def git_push():
    repo = Repo('.')
    repo.git.add('content/posts')
    repo.index.commit(f"auto: push new hot post {datetime.datetime.now().isoformat()}")
    origin = repo.remote(name='origin')
    origin.push()

# 主流程
def job():
    hots = fetch_baidu_hot()
    for title in hots:
        content = generate_article(title)
        write_post(title, content)
    git_push()
    print(f"[{datetime.datetime.now()}] 已自动生成并推送热点文章")

# 每分钟执行一次
def main():
    schedule.every(1).minutes.do(job)
    while True:
        schedule.run_pending()
        time.sleep(1)

if __name__ == '__main__':
    main()
