<!-- Use this file to provide workspace-specific custom instructions to Copilot. For more details, visit https://code.visualstudio.com/docs/copilot/copilot-customization#_use-a-githubcopilotinstructionsmd-file -->

本项目为 Hugo 静态博客，适用于 Vercel 自动化部署。请优先生成与 Hugo 相关的内容和配置。
